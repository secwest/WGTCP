"""WireguardTCP compatibility tests."""
