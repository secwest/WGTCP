/* SPDX-License-Identifier: GPL-2.0 */
/*
 * Copyright (C) 2015-2019 Jason A. Donenfeld <Jason@zx2c4.com>. All Rights Reserved.
 * TCP Support Copyright (c) 2024 Jeff Nathan and Dragos Ruiu. All Rights Reserved.
 */

#ifndef _WG_DEVICE_H
#define _WG_DEVICE_H

#include "noise.h"
#include "allowedips.h"
#include "peerlookup.h"
#include "cookie.h"


#include <linux/types.h>
#include <linux/netdevice.h>
#include <linux/workqueue.h>
#include <linux/ktime.h>
#include <linux/mutex.h>
#include <linux/net.h>
#include <linux/ptr_ring.h>
#include <linux/spinlock.h>

struct wg_device;

struct multicore_worker {
	void *ptr;
	struct work_struct work;
};

struct crypt_queue {
	struct ptr_ring ring;
	struct multicore_worker __percpu *worker;
	int last_cpu;
};

struct prev_queue {
	struct sk_buff *head, *tail, *peeked;
	/* Must match the first two members of struct sk_buff. */
	struct { struct sk_buff *next, *prev; } empty;
	atomic_t count;
};

struct endpoint {
	union {
		struct sockaddr addr;
		struct sockaddr_in addr4;
		struct sockaddr_in6 addr6;
	};
	union {
		struct {
			struct in_addr src4;
			/* Essentially the same as addr6->scope_id */
			int src_if4;
		};
		struct in6_addr src6;
	};
};

#define WG_TCP_ACCEPT_SOURCE_SLOTS 128

struct wg_tcp_accept_source {
	union {
		__be32 addr4;
		struct in6_addr addr6;
	} address;
	unsigned long window_started;
	unsigned long last_seen;
	u32 scope_id;
	u16 accepts;
	sa_family_t family;
};

struct wg_device {
	struct net_device *dev;
	struct crypt_queue encrypt_queue, decrypt_queue, handshake_queue;
	struct sock __rcu *sock4, *sock6; /* UDP listening sockets */
	struct socket __rcu *tcp_listen_socket4, *tcp_listen_socket6; /* TCP listening sockets */
	struct net __rcu *creating_net;
	struct noise_static_identity static_identity;
	struct workqueue_struct *packet_crypt_wq,*handshake_receive_wq, *handshake_send_wq;
	struct workqueue_struct *tcp_auth_wq;
	struct cookie_checker cookie_checker;
	struct pubkey_hashtable *peer_hashtable;
	struct index_hashtable *index_hashtable;
	struct allowedips peer_allowedips;
	struct mutex device_update_lock, socket_update_lock;
	struct endpoint device_endpoint;
	struct list_head device_list, peer_list, tcp_connection_list;
	struct task_struct *tcp_listener4_thread, *tcp_listener6_thread;
	struct delayed_work tcp_cleanup_work;
	struct delayed_work tcp_route_work;
        spinlock_t tcp_cleanup_lock; /* Add a spinlock to protect the flag */
	bool tcp_cleanup_scheduled;
	bool tcp_socket4_ready;
	bool tcp_socket6_ready;
	bool listener_active;
	spinlock_t tcp_connection_list_lock;
	unsigned int tcp_pending_connections;
	unsigned int tcp_tracked_connections;
	atomic64_t tcp_connection_sequence;
	spinlock_t tcp_accept_lock;
	struct wg_tcp_accept_source tcp_accept_sources[WG_TCP_ACCEPT_SOURCE_SLOTS];
	atomic_t handshake_queue_len;
	unsigned int num_peers, device_update_gen;
	u32 fwmark;
	u16 incoming_port;
	u8 transport;
};

int wg_device_init(void);
void wg_device_uninit(void);

#endif /* _WG_DEVICE_H */
